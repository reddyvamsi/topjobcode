import {Route, Routes } from "react-router-dom"
import Contactus from "./Contactus";
 import Navigation from "./Navigation";
import Home from "./Home";
import Jobs from "./Jobs";
import Applayforjob from './Applayforjob';
import Comingsoon from "./Comingsoon";
const Routs=()=>{
    return (
        <>
        <Navigation/>
            <Routes>
            <Route path="/" element={<Home/>}/>
            <Route path="home" element={<Home/>}/>
        <Route path="contactus" element={<Contactus/>}/>
        <Route path="jobs" element={<Jobs/>}/>
        <Route path="Applayforjob/:id" element={<Applayforjob/>}/>
        <Route path="comingsoon" element={<Comingsoon/>}/>
        </Routes>
        </>
    )
}
export default Routs

