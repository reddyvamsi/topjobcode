import "./Contactus.css";
import conUS from "../images/conUS.jpg";
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import "./Applayforjob.css";
import axios from "axios";

const Contactus = () => {
  const [userInfo, setUserInfo] = useState();
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset
  } = useForm();
  const onSubmit = (data) => {
    console.log("form data", data);
    setUserInfo(data);
    reset();
    axios.post("http://localhost:1111/contactus", data).then((res) => {});
  };
  return (
    <>
      <div class="container">
        <div class="row" style={{ position: "relative", top: "3rem" }}>
          <div class="col-lg-6 col-sm-12">
            <p className="titlestyle">Get In Touch</p>
            <pre>{JSON.stringify(userInfo, undefined, 2)}</pre>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div class="form-group">
                <input
                  type="text"
                  class="form-control inputsapce"
                  id="exampleInputname"
                  aria-describedby="emailHelp"
                  name="usernmae"
                  placeholder="Name"
                  {...register("username", {
                    required: "Username is required",
                    minLength:{
                      value:4,
                    message:"Username should contain four characters",
                    },
                    maxLength:{
                      value:10,
                      message:"username is to long",
                    }
                  })}
                ></input>
              </div>
              <p className="dangerclass">{errors.username &&(errors.username.message)}</p>
              <div class="form-group">
                <input
                  type="email"
                  class="form-control inputsapce"
                  id="exampleInputEmail1"
                  {...register("email", { required: "Email is required",
                  pattern:{
                    value:/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/g,
                    message:"Invalid email address"
                  }
                })}
                  name="email"
                  aria-describedby="password"
                  placeholder="Enter email"
                ></input>
              </div>
              <p className="dangerclass">{errors.email &&(errors.email.message)}</p>

              <div class="form-group">
                <input
                  type="password"
                  class="form-control inputsapce"
                  id="password"
                  {...register("password", {
                    required: "password is required",
                    minLength:{
                      value:4,
                    message:"password should contain four characters",
                    },
                    maxLength:{
                      value:10,
                      message:"password is to long",
                    }

                  })}
                  name="password"
                  aria-describedby="emailHelp"
                  placeholder="Enter Password"
                ></input>
              </div>
              <p className="dangerclass">{errors.password &&(errors.password.message)}</p>

              <div class="form-group">
                <textarea
                  class="form-control inputsapce"
                  id="comments"
                  {...register("comments", {
                    required: "comments is required",
                    minLength:{
                      value:10,
                    message:"comments should contain ten characters",
                    },
                    maxLength:{
                      value:50,
                      message:"comments is to long",
                    }
                  })}
                  name="comments"
                  aria-describedby="comments"
                  placeholder="Enter comments"
                  rows="3"
                ></textarea>
              </div>
              <p className="dangerclass">{errors.comments &&(errors.comments.message)}</p>
              <button type="submit" class="btn btn-success col-12">
                Submit
              </button>
            </form>
          </div>

          <div class="col-lg-6 col-sm-12">
            <img
              style={{ height: "400px" }}
              className="d-block w-100"
              src={conUS}
              alt="First slide"
            />
          </div>
        </div>
      </div>
    </>
  );
};
export default Contactus;
