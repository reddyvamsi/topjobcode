import React from "react";
import './Navigation.css'
import { Link } from "react-router-dom";
const Navigation=()=>{
    return (
        <>
        <nav class="navbar navbar-expand-sm navbar-light navcolor">
	  <div class="container-fluid ">	
		<Link to="/" className="linkstylefornav">TopJobs</Link>
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		  <span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse " id="navbarSupportedContent">
		  <ul class="navbar-nav ms-auto">
			<li class="nav-item">
			  <Link to="/home" className="linkstylefornav">Home</Link>
			</li>
			<li class="nav-item">
			  <Link to="/contactus" className="linkstylefornav">CONTACT US</Link>
			</li>
            <li class="nav-item">
			  <Link to="/jobs" className="linkstylefornav">JOBS</Link>
			</li>			
		  </ul>		  
		</div>
	  </div>
	</nav>
        </>
    )
}
export default Navigation