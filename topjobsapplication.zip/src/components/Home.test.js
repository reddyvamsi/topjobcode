import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import  Home from"../components/Home"

test('renders learn react link', () => {
  render(<BrowserRouter><Home /></BrowserRouter>);
  const linkElement = screen.getByText(/first slide label/i);
  expect(linkElement).toBeInTheDocument();
});
it('uses correct src', async () => {

    render(<BrowserRouter><Home /></BrowserRouter>);
  
      const image = screen.getByAltText('First slide');
  
      expect(image.src).toContain('carousel_1.jpg');
  
  });