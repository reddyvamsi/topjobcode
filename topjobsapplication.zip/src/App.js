
import './App.css';
import Routs from './components/Routs';

function App() {
  return (
   <>
     <Routs></Routs>
   </>
  );
}
export default App;
