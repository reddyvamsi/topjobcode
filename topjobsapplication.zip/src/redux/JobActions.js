import axios from "axios";
export const getEmp = () => {
    return function(dispatch) {
         axios.get('http://localhost:1111/jobs')
        .then(data => {
            console.log("krishna", data);
                dispatch({
                type: "employee/getById",
                data: data.data
            });
        });
    };
}
export const applyJobs = (info) => {
       console.log(info)
    return function(dispatch){
        axios.post('http://localhost:1111/Appliedjobs',info).then(res => {
           console.log(res);
            dispatch({
            type: 'APPLY_JOBS',
            payload: res.data

        })

        })

        .catch(error => console.log(error));

    }

}









// export const applyjobs = (info) => {
//     console.log(info);
//     return function(dispatch){
//         alert("");
//         axios.post('http://localhost:1111/Appliedjobs', info)
//         .then(res => {
//             console.log("krishna", res.data);
//             dispatch({
//                 type: 'APPLY_JOBS',
//                 payload: res.data
//             })
//         })
//         .catch(error => console.log(error));  
//     }
// }
//testing

// export const empcantact = (contactus) => {
//     if (contactus) {
//         return async function(dispatch, getState) {
//             await axios.post('http://localhost:1111/contactus', contactus)
//             .then(data => {
//                 console.log("vamsikrishna", data);
//             });
//         };
//     }
// }











export const contactus=(contact)=>{
    console.log();
    return function(dispatch){
    axios.post('http://localhost:1111/contactus',contact).then(res =>{
        console.log(res);
    })
    .catch(error => console.log(error));
    }
}